# FDE Assessment - MCP and LLM Gateways

This project implements the four assessment tasks as small, deployable Python components. The code intentionally favors explicit control flow, defensive validation, and standard-library dependencies where they make the transport behavior easy to inspect.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
pytest -q
```

## Components

| Task | Module | Run |
| --- | --- | --- |
| 1. MCP server | `fde_assessment.mcp_server` | `python -m fde_assessment.mcp_server` |
| 2. MCP security proxy | `fde_assessment.mcp_proxy` | `python -m fde_assessment.mcp_proxy --port 8080 --downstream-url http://localhost:8081` |
| 3. Streaming PII guardrail | `fde_assessment.streaming_guardrail` | import `redact_stream` in an ASGI/LLM proxy handler |
| 4. Rate limit + fallback router | `fde_assessment.routing` | import `GatewayRouter` in an LLM gateway |

### Task 1: custom MCP server

Uses the official Python MCP SDK and `FastMCP` over stdio. The SDK owns the JSON-RPC transport and error envelope. All application logging is sent to stderr; do not add `print()` calls, because stdout is reserved for protocol frames.

Tools:

- `get_customer_record(customer_id)` accepts `CUST-` followed by five digits.
- `trigger_refund(customer_id, amount, reason)` additionally requires a positive amount and a reason with at least 10 characters.

Malformed tool arguments raise `ValueError`; the MCP SDK maps this safely into its tool/JSON-RPC response rather than corrupting the transport.

### Task 2: MCP gateway proxy

The proxy accepts HTTP JSON-RPC requests and requires `Authorization: Bearer <token>`. Demo tokens are supplied through `MCP_ROLE_TOKENS`, for example:

```bash
export MCP_ROLE_TOKENS='viewer-token:viewer,admin-token:admin'
```

`tools/list` is transparently forwarded. Calls to a tool beginning with `admin_` require the `admin` role. Unauthorized calls receive JSON-RPC error `-32001`, and are never forwarded downstream.

### Task 3: streaming guardrail

`StreamingPIIRedactor` keeps only a bounded trailing buffer (320 characters by default). It redacts e-mail addresses, US Social Security numbers, and 13-19 digit credit-card-like numbers, including patterns split across chunks. It does not accumulate the complete model response.

### Task 4: resilient LLM router

`SlidingWindowRateLimiter` stores per-tenant token events in SQLite and uses `BEGIN IMMEDIATE` to make each admission decision atomic across processes sharing the database. `GatewayRouter` applies a 3-second primary timeout and falls back for timeouts or 429-style `UpstreamRateLimited` errors. Client errors are sanitized into a stable gateway payload.

## Design notes

- The example customer records and role tokens are deliberately mock data; replace them with database/auth providers in a real deployment.
- The rate limiter uses a timestamped event log, which is a true sliding window. Add database retention/partitioning for very high traffic.
- The streaming detector is deliberately conservative: it holds a small suffix before emitting to prevent PII fragments from leaking at chunk boundaries.
