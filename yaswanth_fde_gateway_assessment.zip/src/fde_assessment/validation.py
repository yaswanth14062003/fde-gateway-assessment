"""Validation shared by the MCP tools and unit tests."""

from __future__ import annotations

from typing import Annotated

from pydantic import BaseModel, Field, StringConstraints

CustomerId = Annotated[str, StringConstraints(pattern=r"^CUST-\d{5}$")]


class CustomerLookup(BaseModel):
    customer_id: CustomerId


class RefundRequest(BaseModel):
    customer_id: CustomerId
    amount: float = Field(gt=0, allow_inf_nan=False)
    reason: Annotated[str, StringConstraints(strip_whitespace=True, min_length=10)]


def validate_customer_id(customer_id: str) -> str:
    """Pydantic validates the exact customer ID schema and returns normalized data."""
    return CustomerLookup(customer_id=customer_id).customer_id


def validate_refund(customer_id: str, amount: float, reason: str) -> RefundRequest:
    return RefundRequest(customer_id=customer_id, amount=amount, reason=reason)
