"""Task 1: stdio MCP server. Never write application logs to stdout."""

from __future__ import annotations

import logging
import sys

from mcp.server.fastmcp import FastMCP

from .validation import validate_customer_id, validate_refund

logging.basicConfig(stream=sys.stderr, level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger(__name__)
mcp = FastMCP("customer-service-tools")

_CUSTOMERS = {
    "CUST-00001": {"customer_id": "CUST-00001", "name": "Jordan Lee", "status": "active"},
    "CUST-00002": {"customer_id": "CUST-00002", "name": "Sam Patel", "status": "active"},
}


@mcp.tool()
def get_customer_record(customer_id: str) -> dict[str, str]:
    """Return a mock customer record for a validated customer identifier."""
    customer_id = validate_customer_id(customer_id)
    logger.info("Customer lookup requested for %s", customer_id)
    return _CUSTOMERS.get(customer_id, {"customer_id": customer_id, "status": "not_found"})


@mcp.tool()
def trigger_refund(customer_id: str, amount: float, reason: str) -> dict[str, object]:
    """Create a mock refund request after strict validation."""
    request = validate_refund(customer_id, amount, reason)
    logger.info("Refund requested for %s", request.customer_id)
    return {
        "status": "accepted",
        "customer_id": request.customer_id,
        "amount": request.amount,
        "reason": request.reason,
    }


if __name__ == "__main__":
    mcp.run(transport="stdio")
