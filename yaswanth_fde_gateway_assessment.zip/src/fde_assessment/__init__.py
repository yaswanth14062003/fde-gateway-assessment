"""Practical MCP and LLM gateway assessment components."""
