"""Task 3: bounded-memory PII redaction for streamed text deltas."""

from __future__ import annotations

import re
from collections.abc import AsyncIterator

EMAIL = re.compile(r"(?<![\w.+-])[\w.+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+")
SSN = re.compile(r"(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)")
CARD = re.compile(r"(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)")


def redact_pii(text: str) -> str:
    """Redact the requested sensitive patterns without logging source text."""
    for pattern in (EMAIL, SSN, CARD):
        text = pattern.sub("[REDACTED]", text)
    return text


class StreamingPIIRedactor:
    """Retain a small suffix so PII split over chunks is still detected."""

    def __init__(self, holdback_chars: int = 320) -> None:
        if holdback_chars < 64:
            raise ValueError("holdback_chars must be at least 64")
        self.holdback_chars = holdback_chars
        self._buffer = ""

    def push(self, delta: str) -> str:
        if not isinstance(delta, str):
            raise TypeError("stream delta must be text")
        self._buffer += delta
        if len(self._buffer) <= self.holdback_chars:
            return ""
        safe, self._buffer = self._buffer[:-self.holdback_chars], self._buffer[-self.holdback_chars:]
        return redact_pii(safe)

    def finish(self) -> str:
        result, self._buffer = redact_pii(self._buffer), ""
        return result


async def redact_stream(deltas: AsyncIterator[str], holdback_chars: int = 320) -> AsyncIterator[str]:
    redactor = StreamingPIIRedactor(holdback_chars)
    async for delta in deltas:
        output = redactor.push(delta)
        if output:
            yield output
    final = redactor.finish()
    if final:
        yield final
