"""Task 4: token-aware SQLite rate limit and resilient provider routing."""

from __future__ import annotations

import asyncio
import sqlite3
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path


class RateLimitExceeded(Exception):
    pass


class UpstreamRateLimited(Exception):
    pass


class UpstreamUnavailable(Exception):
    pass


class SlidingWindowRateLimiter:
    def __init__(self, db_path: str | Path, max_tokens_per_minute: int = 50_000) -> None:
        self.db_path = str(db_path)
        self.max_tokens_per_minute = max_tokens_per_minute
        with self._connect() as connection:
            connection.execute("CREATE TABLE IF NOT EXISTS token_events (tenant TEXT NOT NULL, occurred_at REAL NOT NULL, tokens INTEGER NOT NULL)")
            connection.execute("CREATE INDEX IF NOT EXISTS token_events_window ON token_events (tenant, occurred_at)")

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path, timeout=5, isolation_level=None)

    def admit(self, tenant: str, tokens: int, now: float | None = None) -> None:
        if not tenant or isinstance(tokens, bool) or not isinstance(tokens, int) or tokens <= 0:
            raise ValueError("tenant and a positive integer token count are required")
        now = time.time() if now is None else now
        window_start = now - 60
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute("DELETE FROM token_events WHERE occurred_at < ?", (window_start,))
            used = connection.execute("SELECT COALESCE(SUM(tokens), 0) FROM token_events WHERE tenant = ? AND occurred_at >= ?", (tenant, window_start)).fetchone()[0]
            if used + tokens > self.max_tokens_per_minute:
                connection.rollback()
                raise RateLimitExceeded("tenant token limit exceeded")
            connection.execute("INSERT INTO token_events (tenant, occurred_at, tokens) VALUES (?, ?, ?)", (tenant, now, tokens))
            connection.commit()

    async def admit_async(self, tenant: str, tokens: int) -> None:
        await asyncio.to_thread(self.admit, tenant, tokens)


Provider = Callable[[dict[str, object]], Awaitable[dict[str, object]]]


@dataclass
class GatewayRouter:
    limiter: SlidingWindowRateLimiter
    primary: Provider
    secondary: Provider
    timeout_seconds: float = 3.0

    async def complete(self, tenant: str, request: dict[str, object]) -> dict[str, object]:
        tokens = request.get("estimated_tokens")
        if not isinstance(tokens, int) or isinstance(tokens, bool):
            return self._error("invalid_request", "estimated_tokens must be an integer")
        try:
            await self.limiter.admit_async(tenant, tokens)
        except (RateLimitExceeded, ValueError):
            return self._error("rate_limited", "Tenant token limit exceeded", retryable=True)
        try:
            return await asyncio.wait_for(self.primary(request), timeout=self.timeout_seconds)
        except (asyncio.TimeoutError, UpstreamRateLimited, UpstreamUnavailable):
            try:
                return await asyncio.wait_for(self.secondary(request), timeout=self.timeout_seconds)
            except (asyncio.TimeoutError, UpstreamRateLimited, UpstreamUnavailable):
                return self._error("provider_unavailable", "No model provider is currently available", retryable=True)
            except Exception:
                return self._error("gateway_error", "Secondary model request failed", retryable=True)
        except Exception:
            return self._error("gateway_error", "Primary model request failed", retryable=True)

    @staticmethod
    def _error(code: str, message: str, retryable: bool = False) -> dict[str, object]:
        return {"error": {"code": code, "message": message, "retryable": retryable}}
