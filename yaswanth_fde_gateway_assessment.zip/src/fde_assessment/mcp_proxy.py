"""Task 2: small HTTP JSON-RPC MCP gateway with tool-level authorization."""

from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


def jsonrpc_error(request_id: object, code: int, message: str) -> dict[str, object]:
    return {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}}


def load_token_roles(value: str | None = None) -> dict[str, str]:
    """Parse `token:role,token:role`; use a real identity provider in production."""
    pairs = value if value is not None else os.getenv("MCP_ROLE_TOKENS", "")
    return dict(part.split(":", 1) for part in pairs.split(",") if ":" in part)


@dataclass
class AuthorizationDecision:
    allowed: bool
    response: dict[str, object] | None = None


def authorize_request(payload: object, bearer_token: str | None, token_roles: dict[str, str]) -> AuthorizationDecision:
    if not isinstance(payload, dict) or payload.get("jsonrpc") != "2.0" or not isinstance(payload.get("method"), str):
        request_id = payload.get("id") if isinstance(payload, dict) else None
        return AuthorizationDecision(False, jsonrpc_error(request_id, -32600, "Invalid Request"))

    request_id = payload.get("id")
    role = token_roles.get(bearer_token or "")
    if role is None:
        return AuthorizationDecision(False, jsonrpc_error(request_id, -32001, "Unauthorized"))

    if payload["method"] == "tools/call":
        params = payload.get("params")
        tool_name = params.get("name") if isinstance(params, dict) else None
        if not isinstance(tool_name, str):
            return AuthorizationDecision(False, jsonrpc_error(request_id, -32602, "Invalid tool call parameters"))
        if tool_name.startswith("admin_") and role != "admin":
            return AuthorizationDecision(False, jsonrpc_error(request_id, -32001, "Unauthorized Tool Call"))
    return AuthorizationDecision(True)


class MCPProxyHandler(BaseHTTPRequestHandler):
    downstream_url = "http://localhost:8081"
    token_roles: dict[str, str] = {}

    def log_message(self, fmt: str, *args: object) -> None:
        return  # avoid leaking credentials/request bodies to default HTTP logs

    def _send_json(self, status: int, body: dict[str, object]) -> None:
        encoded = json.dumps(body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def do_POST(self) -> None:
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(content_length))
        except (ValueError, json.JSONDecodeError):
            self._send_json(400, jsonrpc_error(None, -32700, "Parse error"))
            return
        auth_header = self.headers.get("Authorization", "")
        token = auth_header.removeprefix("Bearer ") if auth_header.startswith("Bearer ") else None
        decision = authorize_request(payload, token, self.token_roles)
        if not decision.allowed:
            self._send_json(200, decision.response or jsonrpc_error(None, -32001, "Unauthorized"))
            return
        try:
            request = Request(
                self.downstream_url,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urlopen(request, timeout=10) as downstream:
                body = downstream.read()
                self.send_response(downstream.status)
                self.send_header("Content-Type", downstream.headers.get("Content-Type", "application/json"))
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
        except (HTTPError, URLError, TimeoutError):
            request_id = payload.get("id") if isinstance(payload, dict) else None
            self._send_json(502, jsonrpc_error(request_id, -32000, "Downstream MCP server unavailable"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--downstream-url", required=True)
    args = parser.parse_args()
    MCPProxyHandler.downstream_url = args.downstream_url
    MCPProxyHandler.token_roles = load_token_roles()
    if not MCPProxyHandler.token_roles:
        raise SystemExit("Set MCP_ROLE_TOKENS, e.g. viewer-token:viewer,admin-token:admin")
    ThreadingHTTPServer(("0.0.0.0", args.port), MCPProxyHandler).serve_forever()


if __name__ == "__main__":
    main()
