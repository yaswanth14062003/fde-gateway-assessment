from fde_assessment.mcp_proxy import authorize_request, load_token_roles


ROLES = {"viewer-token": "viewer", "admin-token": "admin"}


def payload(method: str, params: object = None) -> dict[str, object]:
    result: dict[str, object] = {"jsonrpc": "2.0", "id": 7, "method": method}
    if params is not None:
        result["params"] = params
    return result


def test_role_parser() -> None:
    assert load_token_roles("a:viewer,b:admin") == {"a": "viewer", "b": "admin"}


def test_tools_list_is_allowed_for_viewer() -> None:
    assert authorize_request(payload("tools/list"), "viewer-token", ROLES).allowed


def test_viewer_cannot_call_admin_tool() -> None:
    decision = authorize_request(payload("tools/call", {"name": "admin_reset_key"}), "viewer-token", ROLES)
    assert not decision.allowed
    assert decision.response["error"]["code"] == -32001  # type: ignore[index]


def test_admin_can_call_admin_tool() -> None:
    assert authorize_request(payload("tools/call", {"name": "admin_reset_key"}), "admin-token", ROLES).allowed


def test_missing_token_is_rejected() -> None:
    decision = authorize_request(payload("tools/list"), None, ROLES)
    assert decision.response["error"]["code"] == -32001  # type: ignore[index]
