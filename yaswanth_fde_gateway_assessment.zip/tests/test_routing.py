import asyncio

from fde_assessment.routing import GatewayRouter, SlidingWindowRateLimiter, UpstreamRateLimited


def test_sliding_window_limit(tmp_path) -> None:
    limiter = SlidingWindowRateLimiter(tmp_path / "rate.db", max_tokens_per_minute=10)
    limiter.admit("tenant-a", 6, now=100)
    try:
        limiter.admit("tenant-a", 5, now=110)
        assert False, "expected token limit"
    except Exception as exc:
        assert exc.__class__.__name__ == "RateLimitExceeded"
    limiter.admit("tenant-a", 5, now=161)


def test_falls_back_on_primary_429(tmp_path) -> None:
    async def primary(_: dict[str, object]) -> dict[str, object]:
        raise UpstreamRateLimited()

    async def secondary(_: dict[str, object]) -> dict[str, object]:
        return {"provider": "secondary", "text": "ok"}

    router = GatewayRouter(SlidingWindowRateLimiter(tmp_path / "rate.db"), primary, secondary)
    answer = asyncio.run(router.complete("tenant-a", {"estimated_tokens": 10}))
    assert answer["provider"] == "secondary"


def test_rate_limit_response_is_sanitized(tmp_path) -> None:
    async def provider(_: dict[str, object]) -> dict[str, object]:
        return {"text": "unused"}

    router = GatewayRouter(SlidingWindowRateLimiter(tmp_path / "rate.db", max_tokens_per_minute=2), provider, provider)
    answer = asyncio.run(router.complete("tenant-a", {"estimated_tokens": 3}))
    assert answer == {"error": {"code": "rate_limited", "message": "Tenant token limit exceeded", "retryable": True}}
