import asyncio

from fde_assessment.streaming_guardrail import StreamingPIIRedactor, redact_pii, redact_stream


def test_redacts_requested_pii_patterns() -> None:
    text = "Contact a.b@example.com, SSN 123-45-6789, card 4111 1111 1111 1111."
    result = redact_pii(text)
    assert result.count("[REDACTED]") == 3
    assert "example.com" not in result and "123-45-6789" not in result


def test_split_email_never_leaks() -> None:
    redactor = StreamingPIIRedactor(64)
    emitted = redactor.push("Email: sa") + redactor.push("i.reddy@example.com; thank you." * 4) + redactor.finish()
    assert "sai.reddy@example.com" not in emitted
    assert "[REDACTED]" in emitted


def test_async_stream_redacts() -> None:
    async def chunks():
        yield "The number is 123-"
        yield "45-6789 and this is enough trailing text to force the bounded buffer to emit safely. " * 2

    async def collect() -> str:
        return "".join([item async for item in redact_stream(chunks(), holdback_chars=64)])

    result = asyncio.run(collect())
    assert "123-45-6789" not in result
    assert "[REDACTED]" in result
