import pytest

from fde_assessment.validation import validate_customer_id, validate_refund


def test_valid_customer_and_refund() -> None:
    assert validate_customer_id("CUST-12345") == "CUST-12345"
    assert validate_refund("CUST-12345", 18.5, "Duplicate charge").amount == 18.5


@pytest.mark.parametrize("customer_id", ["CUST-1234", "cust-12345", "CUST-ABCDE", 123])
def test_invalid_customer_id_is_rejected(customer_id: object) -> None:
    with pytest.raises(ValueError):
        validate_customer_id(customer_id)  # type: ignore[arg-type]


@pytest.mark.parametrize("amount,reason", [(0, "Valid explanation"), (-1, "Valid explanation"), (5, "too short")])
def test_invalid_refund_arguments_are_rejected(amount: object, reason: str) -> None:
    with pytest.raises(ValueError):
        validate_refund("CUST-12345", amount, reason)  # type: ignore[arg-type]
